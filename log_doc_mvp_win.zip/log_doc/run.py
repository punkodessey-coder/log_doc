"""Запуск DocFlow на Windows (Python 3.12): python run.py [IP] [PORT]
Создаёт .venv, ставит зависимости, собирает фронтенд (если есть Node.js) и стартует сервер."""
import json, os, secrets, shutil, subprocess, sys, venv
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VENV = ROOT / ".venv"
VPY = VENV / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def sh(cmd, **kw):
    print(">", " ".join(map(str, cmd)))
    return subprocess.run(cmd, check=True, **kw)


def bootstrap():
    if sys.version_info[:2] != (3, 12):
        print(f"ВНИМАНИЕ: нужен Python 3.12, сейчас {sys.version.split()[0]}")
    if not VPY.exists():
        print("Создаю виртуальное окружение...")
        venv.create(VENV, with_pip=True)
    stamp = VENV / ".deps_ok"
    req = ROOT / "backend" / "requirements.txt"
    if not stamp.exists() or stamp.stat().st_mtime < req.stat().st_mtime:
        sh([str(VPY), "-m", "pip", "install", "--upgrade", "pip"])
        sh([str(VPY), "-m", "pip", "install", "-r", str(req)])
        stamp.write_text("ok")
    os.execv(str(VPY), [str(VPY), str(Path(__file__).resolve()), "--inside", *sys.argv[1:]])


def build_frontend():
    fe = ROOT / "frontend"
    if (fe / "dist" / "index.html").exists():
        return
    npm = shutil.which("npm")
    if not npm:
        print("Node.js не найден: интерфейс не собран, будет доступен только API (/api/docs).")
        print("Установите Node.js 18+ (https://nodejs.org) и запустите снова.")
        return
    sh([npm, "install", "--no-audit", "--no-fund"], cwd=fe)
    sh([npm, "run", "build"], cwd=fe)


def main():
    args = [a for a in sys.argv[1:] if a != "--inside"]
    host = args[0] if len(args) > 0 else "0.0.0.0"
    port = int(args[1]) if len(args) > 1 else 8000
    data = ROOT / "data"
    (data / "storage").mkdir(parents=True, exist_ok=True)
    cfg_file = data / "config.json"
    first = not cfg_file.exists()
    if first:
        cfg_file.write_text(json.dumps({
            "app_secret_key": secrets.token_urlsafe(48),
            "admin_password": secrets.token_urlsafe(12) + "A1!"}, indent=2))
    cfg = json.loads(cfg_file.read_text())
    os.environ.setdefault("DATABASE_URL", "sqlite:///" + (data / "docflow.db").as_posix())
    os.environ.setdefault("STORAGE_ROOT", str(data / "storage"))
    os.environ.setdefault("APP_SECRET_KEY", cfg["app_secret_key"])
    os.environ.setdefault("INITIAL_ADMIN_PASSWORD", cfg["admin_password"])
    build_frontend()
    shown = "localhost" if host in ("0.0.0.0", "::") else host
    print("\n" + "=" * 60)
    print(f" DocFlow: http://{shown}:{port}   (API: /api/docs)")
    print(f" Логин: admin   Пароль: {cfg['admin_password']}")
    print(f" (пароль хранится в {cfg_file}; смените его после входа)")
    print("=" * 60 + "\n")
    import uvicorn
    uvicorn.run("app.main:app", host=host, port=port, app_dir=str(ROOT / "backend"))


if __name__ == "__main__":
    if "--inside" not in sys.argv:
        bootstrap()
    else:
        main()
