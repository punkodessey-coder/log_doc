@echo off
chcp 65001 >nul
cd /d "%~dp0"
rem Использование: start.bat [IP] [ПОРТ]   по умолчанию 0.0.0.0 8000
set HOST=%~1
set PORT=%~2
if "%HOST%"=="" set HOST=0.0.0.0
if "%PORT%"=="" set PORT=8000
where py >nul 2>nul && (py -3.12 run.py %HOST% %PORT%) || (python run.py %HOST% %PORT%)
pause
